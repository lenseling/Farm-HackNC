# HackNC 2022 Submission - Begonia Grove

The Team: Lili E, Ruth W, Ruiyi D

## What is Begonia Grove?

Begonia Grove is a heartfelt, coming of age visual novel constructed completely in the engine Ren'Py. For those unfamiliar with Ren'Py, it utilizes python scripting to create interactive experiences. Play the game by downloading the zip file or open link here:

## Synopsis

You are a 28 year old who has been living in the city for all their life. Seeking change, you arrive at your P.O. box to find a letter telling you
that you have inherited the farm of your late grandfather. You must now embark on a new chapter in your life to manage this mysterious farm, meet new suitors, and find yourself along the way.

## Note
When downloading the zipfile, make sure to change permissions in your settings. On Mac, go to System Preferences, Security & Privacy, and General. Allow Begonia Grove to open here.
